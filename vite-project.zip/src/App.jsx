import Contacts from "./Component/Contacts"
import Header from "./Component/Header"

function App() {
 

  return (
    <>
      
      <Header />
      <Contacts />
      
    </>
  )
}

export default App
